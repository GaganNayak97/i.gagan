Place your payment QR code image here as: payment-qr.png
