// Only these 3 products exist across the whole site.
export const PRODUCTS = [
  {
    id: 1,
    name: "Dell S2725HSM 27-inch Full HD IPS Monitor with Dual Speakers",
    brand: "Dell S-Series",
    category: "Electronics",
    mrp: 14599,
    price: 12399,
    image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=700&q=80",
    rating: 4.3,
    reviews: 1240,
    shortDesc: "27-inch Full HD LED Backlit IPS Panel, 2x HDMI, built-in 6W dual speakers, flicker-free eye comfort screen.",
    description:
      "Enjoy a bright, detailed viewing experience with this 27-inch Full HD IPS monitor. It features an LED-backlit IPS panel for wide viewing angles and accurate colours, two HDMI ports for flexible connectivity, and built-in 6W dual speakers so you don't need external speakers for everyday use. TUV Rheinland certified flicker-free technology and low blue light help reduce eye strain during long work sessions.",
    specs: [
      ["Screen Size", "27 inch (68.58 cm)"],
      ["Resolution", "1920 x 1080 (Full HD)"],
      ["Panel Type", "IPS"],
      ["Ports", "2x HDMI, VGA"],
      ["Speakers", "Built-in 6W dual speakers"],
      ["Eye Comfort", "TUV Rheinland 4-Star, Flicker-free"],
      ["Warranty", "3 Years Standard Warranty"]
    ]
  },
  {
    id: 2,
    name: "Canon EOS R100 Mirrorless Camera with RF-S 18-45mm f/4.5-6.3 IS STM Lens",
    brand: "Canon",
    category: "Cameras",
    mrp: 46990,
    price: 42499,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=700&q=80",
    rating: 4.5,
    reviews: 860,
    shortDesc: "24.1MP APS-C mirrorless camera with RF-S 18-45mm kit lens, ideal for beginners and hybrid shooters.",
    description:
      "The Canon EOS R100 is a compact, lightweight mirrorless camera built for beginners stepping up from a smartphone. It pairs a 24.1MP APS-C CMOS sensor with Canon's DIGIC 8 processor for sharp stills and smooth Full HD video. The included RF-S 18-45mm f/4.5-6.3 IS STM lens covers everyday wide-angle to short telephoto shots, with built-in image stabilisation for steadier handheld shots.",
    specs: [
      ["Sensor", "24.1 MP APS-C CMOS"],
      ["Lens Included", "RF-S 18-45mm f/4.5-6.3 IS STM"],
      ["Video", "Full HD 1080p"],
      ["Autofocus", "Dual Pixel CMOS AF"],
      ["Connectivity", "Wi-Fi, Bluetooth"],
      ["Battery Life", "Approx. 320 shots per charge"],
      ["Warranty", "2 Years Canon India Warranty"]
    ]
  },
  {
    id: 3,
    name: "Trivety Embroidered Semi-Stitched Lehenga Choli",
    brand: "Trivety",
    category: "Fashion",
    mrp: 2499,
    price: 1999,
    image: "https://images.unsplash.com/photo-1610030181087-540f6ee13e50?w=700&q=80",
    rating: 4.1,
    reviews: 530,
    shortDesc: "Semi-stitched embroidered lehenga choli set with dupatta, perfect for festive and wedding occasions.",
    description:
      "This semi-stitched lehenga choli set features fine embroidery work across the choli and lehenga, paired with a matching dupatta. The semi-stitched design allows for a custom fit at your local tailor, making it a versatile pick for weddings, festivals and other celebrations. Made from comfortable, skin-friendly fabric suitable for long wear.",
    specs: [
      ["Type", "Semi-Stitched Lehenga Choli Set"],
      ["Includes", "Lehenga, Choli, Dupatta"],
      ["Work", "Embroidered"],
      ["Fabric", "Blended fabric, skin-friendly"],
      ["Wash Care", "Dry Clean Recommended"],
      ["Occasion", "Wedding, Festive, Party"]
    ]
  }
];

export function getProductById(id) {
  return PRODUCTS.find((p) => String(p.id) === String(id));
}

export function discountPercent(product) {
  return Math.round(((product.mrp - product.price) / product.mrp) * 100);
}
