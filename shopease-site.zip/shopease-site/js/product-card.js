import { discountPercent } from "./data.js";
import { isInCart, isInWishlist, addToCart, toggleWishlist } from "./storage.js";
import { formatINR, showToast, updateBadges } from "./ui.js";

export function productCardHTML(product) {
  const discount = discountPercent(product);
  const inCart = isInCart(product.id);
  const wished = isInWishlist(product.id);

  return `
    <div class="product-card" data-id="${product.id}">
      <button class="wish-btn ${wished ? "active" : ""}" data-wish="${product.id}" aria-label="Wishlist">
        ${wished ? "♥" : "♡"}
      </button>
      <a href="product-details.html?id=${product.id}">
        <img class="thumb" src="${product.image}" alt="${product.name}" />
      </a>
      <div class="info">
        <a href="product-details.html?id=${product.id}">
          <div class="name">${product.name}</div>
        </a>
        <div class="price-row">
          <span class="price">${formatINR(product.price)}</span>
          <span class="mrp">${formatINR(product.mrp)}</span>
          <span class="discount">${discount}% off</span>
        </div>
        <span class="offer-tag">Special Price Deal</span>
        <button class="add-btn ${inCart ? "in-cart" : ""}" data-add="${product.id}">
          ${inCart ? "Added ✓" : "Add to Cart"}
        </button>
      </div>
    </div>
  `;
}

export function bindProductCardEvents(container) {
  container.querySelectorAll("[data-wish]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const id = Number(btn.dataset.wish);
      toggleWishlist(id);
      const nowWished = isInWishlist(id);
      btn.classList.toggle("active", nowWished);
      btn.textContent = nowWished ? "♥" : "♡";
      showToast(nowWished ? "Added to Wishlist" : "Removed from Wishlist");
      updateBadges();
    });
  });

  container.querySelectorAll("[data-add]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const id = Number(btn.dataset.add);
      addToCart(id, 1);
      btn.textContent = "Added ✓";
      btn.classList.add("in-cart");
      showToast("Added to Cart");
      updateBadges();
    });
  });
}
