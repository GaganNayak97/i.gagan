import { cartCount, wishlistCount } from "./storage.js";

export function formatINR(num) {
  return "₹" + Number(num).toLocaleString("en-IN");
}

export function renderHeader(activePage, opts = {}) {
  const root = document.getElementById("header-root");
  if (!root) return;

  if (opts.simple) {
    root.innerHTML = `
      <header class="page-title-bar">
        <a href="${opts.backHref || "javascript:history.back()"}" class="back">←</a>
        <span>${opts.title || ""}</span>
      </header>
    `;
    return;
  }

  root.innerHTML = `
    <header class="site-header">
      <a href="index.html" class="logo">Shop<span>Ease</span></a>
      <div class="search-box">
        <span>🔍</span>
        <input type="text" placeholder="Search Dell Monitor, Canon Camera, Lehenga..." id="search-input" />
      </div>
      <a href="wishlist.html" class="icon-btn" title="Wishlist">
        ♡
        <span class="badge" id="wishlist-badge" style="display:none;">0</span>
      </a>
      <a href="cart.html" class="icon-btn" title="Cart">
        🛒
        <span class="badge" id="cart-badge" style="display:none;">0</span>
      </a>
    </header>
  `;

  const searchInput = document.getElementById("search-input");
  if (searchInput) {
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const q = encodeURIComponent(searchInput.value.trim());
        window.location.href = `products.html?search=${q}`;
      }
    });
  }

  updateBadges();
}

export function renderBottomNav(activePage) {
  const root = document.getElementById("bottomnav-root");
  if (!root) return;

  const items = [
    { key: "home", href: "index.html", icon: "🏠", label: "Home" },
    { key: "products", href: "products.html", icon: "🛍️", label: "Products" },
    { key: "cart", href: "cart.html", icon: "🛒", label: "Cart", badgeId: "nav-cart-badge" },
    { key: "wishlist", href: "wishlist.html", icon: "♡", label: "Wishlist", badgeId: "nav-wishlist-badge" },
    { key: "orders", href: "orders.html", icon: "📦", label: "Orders" }
  ];

  root.innerHTML = `
    <nav class="bottom-nav">
      ${items
        .map(
          (it) => `
        <a href="${it.href}" class="${it.key === activePage ? "active" : ""}">
          <span class="nav-icon">${it.icon}</span>
          <span>${it.label}</span>
          ${it.badgeId ? `<span class="nav-badge" id="${it.badgeId}" style="display:none;">0</span>` : ""}
        </a>
      `
        )
        .join("")}
    </nav>
  `;

  updateBadges();
}

export function updateBadges() {
  const cCount = cartCount();
  const wCount = wishlistCount();

  const cartBadge = document.getElementById("cart-badge");
  const wishBadge = document.getElementById("wishlist-badge");
  const navCartBadge = document.getElementById("nav-cart-badge");
  const navWishBadge = document.getElementById("nav-wishlist-badge");

  [
    [cartBadge, cCount],
    [wishBadge, wCount],
    [navCartBadge, cCount],
    [navWishBadge, wCount]
  ].forEach(([el, count]) => {
    if (!el) return;
    el.textContent = count;
    el.style.display = count > 0 ? "flex" : "none";
  });
}

export function showToast(message, duration = 1800) {
  let toast = document.getElementById("global-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "global-toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove("show"), duration);
}
