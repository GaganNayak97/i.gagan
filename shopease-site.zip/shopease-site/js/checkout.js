import { getProductById } from "./data.js";
import { renderHeader, formatINR, showToast } from "./ui.js";
import { getCart, saveCheckoutDraft } from "./storage.js";

renderHeader(null, { simple: true, title: "Checkout" });

const params = new URLSearchParams(window.location.search);
const buyNowId = params.get("buyNow");

function getCheckoutItems() {
  if (buyNowId) {
    const product = getProductById(Number(buyNowId));
    return product ? [{ ...product, qty: 1 }] : [];
  }
  return getCart()
    .map((entry) => {
      const product = getProductById(entry.id);
      return product ? { ...product, qty: entry.qty } : null;
    })
    .filter(Boolean);
}

const items = getCheckoutItems();
const itemsRoot = document.getElementById("checkout-items-root");
const summaryRoot = document.getElementById("checkout-summary-root");
const barRoot = document.getElementById("checkout-bar-root");

if (items.length === 0) {
  itemsRoot.innerHTML = `
    <div class="empty-state">
      <div class="emoji">🛒</div>
      <p>No items to checkout.</p>
      <a class="shop-btn" href="products.html">Shop Now</a>
    </div>
  `;
} else {
  itemsRoot.innerHTML = items
    .map(
      (item) => `
    <div class="row-card">
      <img src="${item.image}" alt="${item.name}" />
      <div class="row-info">
        <div class="row-name">${item.name}</div>
        <div class="row-price">${formatINR(item.price)} × ${item.qty}</div>
      </div>
    </div>
  `
    )
    .join("");

  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const deliveryFee = subtotal > 500 ? 0 : 49;
  const total = subtotal + deliveryFee;

  summaryRoot.innerHTML = `
    <div class="summary-card">
      <h3>Order Summary</h3>
      <div class="summary-row"><span>Subtotal</span><span>${formatINR(subtotal)}</span></div>
      <div class="summary-row"><span>Delivery Fee</span><span class="${deliveryFee === 0 ? "free" : ""}">${
    deliveryFee === 0 ? "FREE" : formatINR(deliveryFee)
  }</span></div>
      <div class="summary-row total"><span>Total Payable</span><span>${formatINR(total)}</span></div>
    </div>
  `;

  barRoot.innerHTML = `
    <div class="checkout-bar">
      <div class="amt">${formatINR(total)}<small>${items.length} item${items.length !== 1 ? "s" : ""}</small></div>
      <button id="continue-payment">Continue to Pay</button>
    </div>
  `;

  document.getElementById("continue-payment").addEventListener("click", () => {
    if (!validateForm()) {
      showToast("Please fill all address fields correctly");
      return;
    }
    const form = document.getElementById("address-form");
    const data = new FormData(form);
    const address = {
      name: data.get("name").trim(),
      phone: data.get("phone").trim(),
      pincode: data.get("pincode").trim(),
      address: data.get("address").trim(),
      city: data.get("city").trim(),
      state: data.get("state").trim()
    };

    saveCheckoutDraft({
      items: items.map((i) => ({ id: i.id, qty: i.qty, name: i.name, price: i.price, image: i.image })),
      address,
      subtotal,
      deliveryFee,
      total,
      isBuyNow: !!buyNowId
    });

    window.location.href = "payment.html";
  });
}

function validateForm() {
  const form = document.getElementById("address-form");
  let valid = true;

  const rules = {
    name: (v) => v.trim().length >= 3,
    phone: (v) => /^[6-9]\d{9}$/.test(v.trim()),
    pincode: (v) => /^\d{6}$/.test(v.trim()),
    address: (v) => v.trim().length >= 5,
    city: (v) => v.trim().length >= 2,
    state: (v) => v.trim().length >= 2
  };

  Object.entries(rules).forEach(([field, rule]) => {
    const group = form.querySelector(`[data-field="${field}"]`);
    const input = form.querySelector(`[name="${field}"]`);
    const isValid = rule(input.value || "");
    group.classList.toggle("invalid", !isValid);
    if (!isValid) valid = false;
  });

  return valid;
}
