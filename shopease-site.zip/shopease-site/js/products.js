import { PRODUCTS } from "./data.js";
import { renderHeader, renderBottomNav } from "./ui.js";
import { productCardHTML, bindProductCardEvents } from "./product-card.js";

renderHeader("products");
renderBottomNav("products");

const categories = ["All", ...new Set(PRODUCTS.map((p) => p.category))];
const chipRow = document.getElementById("chip-row");
const grid = document.getElementById("products-grid");
const resultsCount = document.getElementById("results-count");
const emptyRoot = document.getElementById("empty-root");

const params = new URLSearchParams(window.location.search);
let activeCategory = "All";
let searchTerm = (params.get("search") || "").toLowerCase();

function renderChips() {
  chipRow.innerHTML = categories
    .map(
      (cat) => `
      <button class="chip ${cat === activeCategory ? "active" : ""}" data-cat="${cat}">${cat}</button>
    `
    )
    .join("");

  chipRow.querySelectorAll("[data-cat]").forEach((btn) => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.cat;
      renderChips();
      renderGrid();
    });
  });
}

function renderGrid() {
  let list = PRODUCTS;
  if (activeCategory !== "All") {
    list = list.filter((p) => p.category === activeCategory);
  }
  if (searchTerm) {
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(searchTerm) ||
        p.brand.toLowerCase().includes(searchTerm) ||
        p.category.toLowerCase().includes(searchTerm)
    );
  }

  resultsCount.textContent = `${list.length} Product${list.length !== 1 ? "s" : ""} Found`;

  if (list.length === 0) {
    grid.innerHTML = "";
    emptyRoot.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🔍</div>
        <p>No products match your search.</p>
      </div>
    `;
    return;
  }
  emptyRoot.innerHTML = "";
  grid.innerHTML = list.map(productCardHTML).join("");
  bindProductCardEvents(grid);
}

renderChips();
renderGrid();
