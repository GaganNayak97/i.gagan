import { renderHeader, formatINR, showToast } from "./ui.js";
import { getCheckoutDraft, clearCheckoutDraft, addOrder, clearCart, removeFromCart } from "./storage.js";

renderHeader(null, { simple: true, title: "Payment" });

const draft = getCheckoutDraft();
const amountRoot = document.getElementById("payment-amount-root");
const optionsRoot = document.getElementById("payment-options-root");
const detailRoot = document.getElementById("payment-detail-root");
const payBarRoot = document.getElementById("pay-bar-root");

const UPI_ID = "shopease@ybl"; // Replace with your real UPI ID
const QR_IMAGE_PATH = "images/payment-qr.png"; // Place your QR image file here

if (!draft || !draft.items || draft.items.length === 0) {
  amountRoot.innerHTML = `
    <div class="empty-state">
      <div class="emoji">⚠️</div>
      <p>No pending checkout found.</p>
      <a class="shop-btn" href="cart.html">Go to Cart</a>
    </div>
  `;
} else {
  init();
}

function init() {
  amountRoot.innerHTML = `
    <div class="summary-card">
      <h3>Amount to Pay</h3>
      <div class="summary-row total"><span>Total</span><span>${formatINR(draft.total)}</span></div>
    </div>
  `;

  const methods = [
    { key: "phonepe", icon: "📱", label: "PhonePe UPI", sub: "Pay using PhonePe app" },
    { key: "paytm", icon: "💠", label: "Paytm UPI", sub: "Pay using Paytm app" },
    { key: "qr", icon: "🔳", label: "Scan & Pay with QR", sub: "Use any UPI app to scan" }
  ];

  optionsRoot.innerHTML = methods
    .map(
      (m) => `
    <label class="pay-option">
      <input type="radio" name="pay-method" value="${m.key}" />
      <div class="pay-icon">${m.icon}</div>
      <div>
        <div class="pay-label">${m.label}</div>
        <div class="pay-sub">${m.sub}</div>
      </div>
    </label>
  `
    )
    .join("");

  optionsRoot.querySelectorAll('input[name="pay-method"]').forEach((radio) => {
    radio.addEventListener("change", () => renderMethodDetail(radio.value));
  });

  payBarRoot.innerHTML = `
    <div class="checkout-bar">
      <div class="amt">${formatINR(draft.total)}<small>Total Payable</small></div>
      <button id="confirm-payment" disabled style="opacity:.5;">Confirm Order</button>
    </div>
  `;

  document.getElementById("confirm-payment").addEventListener("click", handleConfirm);
}

function renderMethodDetail(method) {
  const confirmBtn = document.getElementById("confirm-payment");

  let html = "";
  if (method === "phonepe" || method === "paytm") {
    const appName = method === "phonepe" ? "PhonePe" : "Paytm";
    html = `
      <div class="pay-detail-box show">
        <p style="font-size:13.5px;color:var(--muted);margin-top:0;">Pay ${formatINR(
          draft.total
        )} using your ${appName} app to the UPI ID below, then enter the reference / UTR number.</p>
        <div class="upi-id-box" id="upi-id-text">${UPI_ID}</div>
        <button class="copy-btn" id="copy-upi">Copy UPI ID</button>
        <div class="form-group utr-input" data-field="utr" style="text-align:left;margin-top:14px;">
          <label>UTR / Transaction Reference Number</label>
          <input type="text" id="utr-input" placeholder="12-digit UTR number" maxlength="20" />
          <div class="field-error">Please enter a valid transaction reference number</div>
        </div>
      </div>
    `;
  } else if (method === "qr") {
    html = `
      <div class="pay-detail-box show">
        <p style="font-size:13.5px;color:var(--muted);margin-top:0;">Scan this QR code with any UPI app and pay ${formatINR(
          draft.total
        )}, then enter the reference / UTR number.</p>
        <img class="qr-img" src="${QR_IMAGE_PATH}" alt="Payment QR Code"
          onerror="this.replaceWith(Object.assign(document.createElement('div'), {
            style:'width:180px;height:180px;margin:0 auto 10px;border:1px dashed var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:12px;text-align:center;padding:10px;',
            innerText:'QR image not found. Add your QR file at images/payment-qr.png'
          }))" />
        <div class="upi-id-box" id="upi-id-text">${UPI_ID}</div>
        <div class="form-group utr-input" data-field="utr" style="text-align:left;margin-top:14px;">
          <label>UTR / Transaction Reference Number</label>
          <input type="text" id="utr-input" placeholder="12-digit UTR number" maxlength="20" />
          <div class="field-error">Please enter a valid transaction reference number</div>
        </div>
      </div>
    `;
  }

  detailRoot.innerHTML = html;

  const copyBtn = document.getElementById("copy-upi");
  if (copyBtn) {
    copyBtn.addEventListener("click", () => {
      navigator.clipboard?.writeText(UPI_ID).then(() => showToast("UPI ID copied"));
    });
  }

  confirmBtn.disabled = false;
  confirmBtn.style.opacity = "1";
  confirmBtn.dataset.method = method;
}

function handleConfirm() {
  const confirmBtn = document.getElementById("confirm-payment");
  const method = confirmBtn.dataset.method;
  const utrInput = document.getElementById("utr-input");
  const utrGroup = utrInput?.closest(".form-group");

  const utr = utrInput?.value.trim() || "";
  if (!utr || utr.length < 6) {
    utrGroup?.classList.add("invalid");
    showToast("Please enter a valid transaction reference number");
    return;
  }
  utrGroup?.classList.remove("invalid");

  const methodLabels = {
    phonepe: "PhonePe UPI",
    paytm: "Paytm UPI",
    qr: "Scan & Pay QR"
  };

  const order = {
    orderId: "ORD" + Date.now(),
    items: draft.items,
    address: draft.address,
    paymentMethod: methodLabels[method] || method,
    utr,
    subtotal: draft.subtotal,
    deliveryFee: draft.deliveryFee,
    total: draft.total,
    date: new Date().toISOString(),
    status: "Payment Verification Pending"
  };

  addOrder(order);

  if (draft.isBuyNow) {
    draft.items.forEach((i) => removeFromCart(i.id));
  } else {
    clearCart();
  }
  clearCheckoutDraft();

  window.location.href = `orders.html?justPlaced=${order.orderId}`;
}
