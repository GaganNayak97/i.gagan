import { PRODUCTS, discountPercent } from "./data.js";
import { formatINR } from "./ui.js";

const AUTO_INTERVAL = 3500;

export function renderHeroSlider() {
  const root = document.getElementById("hero-slider-root");
  if (!root) return;

  const slides = PRODUCTS;

  root.innerHTML = `
    <div class="hero-slider">
      <button class="hero-arrow prev" aria-label="Previous">‹</button>
      <div class="hero-track" id="hero-track">
        ${slides
          .map(
            (p, i) => `
          <a href="product-details.html?id=${p.id}" class="hero-slide slide-${i % 3}">
            <img src="${p.image}" alt="${p.name}" />
            <div class="hero-copy">
              <span class="hero-tag">Deal of the Day</span>
              <div class="hero-off">${discountPercent(p)}% OFF</div>
              <div class="hero-name">${p.name}</div>
              <div>
                <span class="hero-price">${formatINR(p.price)}</span>
                <span class="hero-mrp">${formatINR(p.mrp)}</span>
              </div>
            </div>
          </a>
        `
          )
          .join("")}
      </div>
      <button class="hero-arrow next" aria-label="Next">›</button>
      <div class="hero-dots" id="hero-dots">
        ${slides.map((_, i) => `<button class="dot ${i === 0 ? "active" : ""}" data-dot="${i}"></button>`).join("")}
      </div>
    </div>
  `;

  const track = document.getElementById("hero-track");
  const dots = [...document.querySelectorAll("#hero-dots .dot")];
  const total = slides.length;
  let index = 0;
  let timer = null;

  function goTo(i) {
    index = (i + total) % total;
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((d, di) => d.classList.toggle("active", di === index));
  }

  function next() {
    goTo(index + 1);
  }
  function prev() {
    goTo(index - 1);
  }

  function startAuto() {
    stopAuto();
    timer = setInterval(next, AUTO_INTERVAL);
  }
  function stopAuto() {
    if (timer) clearInterval(timer);
  }

  root.querySelector(".hero-arrow.next").addEventListener("click", (e) => {
    e.preventDefault();
    next();
    startAuto();
  });
  root.querySelector(".hero-arrow.prev").addEventListener("click", (e) => {
    e.preventDefault();
    prev();
    startAuto();
  });
  dots.forEach((dot) => {
    dot.addEventListener("click", () => {
      goTo(Number(dot.dataset.dot));
      startAuto();
    });
  });

  // swipe support
  let startX = 0;
  let deltaX = 0;
  track.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX;
    stopAuto();
  });
  track.addEventListener("touchmove", (e) => {
    deltaX = e.touches[0].clientX - startX;
  });
  track.addEventListener("touchend", () => {
    if (deltaX > 40) prev();
    else if (deltaX < -40) next();
    deltaX = 0;
    startAuto();
  });

  // pause on hover (desktop)
  root.addEventListener("mouseenter", stopAuto);
  root.addEventListener("mouseleave", startAuto);

  goTo(0);
  startAuto();
}
