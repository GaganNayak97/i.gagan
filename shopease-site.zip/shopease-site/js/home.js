import { PRODUCTS } from "./data.js";
import { renderHeader, renderBottomNav } from "./ui.js";
import { productCardHTML, bindProductCardEvents } from "./product-card.js";
import { renderHeroSlider } from "./hero-slider.js";

renderHeader("home");
renderBottomNav("home");
renderHeroSlider();

const grid = document.getElementById("home-product-grid");
grid.innerHTML = PRODUCTS.map(productCardHTML).join("");
bindProductCardEvents(grid);
