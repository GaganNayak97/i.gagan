import { getProductById } from "./data.js";
import { renderHeader, renderBottomNav, formatINR, showToast, updateBadges } from "./ui.js";
import {
  getCart,
  updateCartQty,
  removeFromCart,
  toggleWishlist,
  isInWishlist
} from "./storage.js";

renderHeader("cart");
renderBottomNav("cart");

const cartList = document.getElementById("cart-list");
const summaryRoot = document.getElementById("cart-summary-root");
const checkoutBarRoot = document.getElementById("checkout-bar-root");

function computeCartItems() {
  return getCart()
    .map((entry) => {
      const product = getProductById(entry.id);
      if (!product) return null;
      return { ...product, qty: entry.qty };
    })
    .filter(Boolean);
}

function render() {
  const items = computeCartItems();

  if (items.length === 0) {
    cartList.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🛒</div>
        <p>Your cart is empty.</p>
        <a class="shop-btn" href="products.html">Shop Now</a>
      </div>
    `;
    summaryRoot.innerHTML = "";
    checkoutBarRoot.innerHTML = "";
    return;
  }

  cartList.innerHTML = items
    .map(
      (item) => `
    <div class="row-card" data-id="${item.id}">
      <a href="product-details.html?id=${item.id}"><img src="${item.image}" alt="${item.name}" /></a>
      <div class="row-info">
        <a href="product-details.html?id=${item.id}"><div class="row-name">${item.name}</div></a>
        <div class="row-price">${formatINR(item.price)}</div>
        <div class="row-actions">
          <div class="qty-control">
            <button data-decr="${item.id}">−</button>
            <span>${item.qty}</span>
            <button data-incr="${item.id}">+</button>
          </div>
          <button class="link-btn move" data-move="${item.id}">Move to Wishlist</button>
          <button class="link-btn" data-remove="${item.id}">Remove</button>
        </div>
      </div>
    </div>
  `
    )
    .join("");

  const totalItems = items.reduce((sum, i) => sum + i.qty, 0);
  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const mrpTotal = items.reduce((sum, i) => sum + i.mrp * i.qty, 0);
  const savings = mrpTotal - subtotal;
  const deliveryFee = subtotal > 500 ? 0 : 49;
  const total = subtotal + deliveryFee;

  summaryRoot.innerHTML = `
    <div class="summary-card">
      <h3>Price Details (${totalItems} item${totalItems !== 1 ? "s" : ""})</h3>
      <div class="summary-row"><span>Total MRP</span><span>${formatINR(mrpTotal)}</span></div>
      <div class="summary-row"><span>Discount on MRP</span><span>− ${formatINR(savings)}</span></div>
      <div class="summary-row"><span>Delivery Fee</span><span class="${deliveryFee === 0 ? "free" : ""}">${
    deliveryFee === 0 ? "FREE" : formatINR(deliveryFee)
  }</span></div>
      <div class="summary-row total"><span>Total Amount</span><span>${formatINR(total)}</span></div>
    </div>
  `;

  checkoutBarRoot.innerHTML = `
    <div class="checkout-bar">
      <div class="amt">${formatINR(total)}<small>View details</small></div>
      <button id="proceed-checkout">Proceed to Checkout</button>
    </div>
  `;

  document.getElementById("proceed-checkout").addEventListener("click", () => {
    window.location.href = "checkout.html";
  });

  bindRowEvents();
}

function bindRowEvents() {
  cartList.querySelectorAll("[data-incr]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.incr);
      const current = getCart().find((c) => c.id === id);
      updateCartQty(id, (current?.qty || 0) + 1);
      updateBadges();
      render();
    });
  });
  cartList.querySelectorAll("[data-decr]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.decr);
      const current = getCart().find((c) => c.id === id);
      const newQty = (current?.qty || 0) - 1;
      updateCartQty(id, newQty);
      updateBadges();
      render();
    });
  });
  cartList.querySelectorAll("[data-remove]").forEach((btn) => {
    btn.addEventListener("click", () => {
      removeFromCart(Number(btn.dataset.remove));
      showToast("Item removed from cart");
      updateBadges();
      render();
    });
  });
  cartList.querySelectorAll("[data-move]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.move);
      if (!isInWishlist(id)) toggleWishlist(id);
      removeFromCart(id);
      showToast("Moved to Wishlist");
      updateBadges();
      render();
    });
  });
}

render();
