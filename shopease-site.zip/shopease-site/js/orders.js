import { renderHeader, renderBottomNav, formatINR } from "./ui.js";
import { getOrders } from "./storage.js";

renderHeader("orders");
renderBottomNav("orders");

const params = new URLSearchParams(window.location.search);
const justPlaced = params.get("justPlaced");

const successRoot = document.getElementById("success-root");
const ordersList = document.getElementById("orders-list");

if (justPlaced) {
  successRoot.innerHTML = `
    <div class="success-box">
      <div class="check">✓</div>
      <h2>Order Placed!</h2>
      <p>Order ID: ${justPlaced}<br/>We'll confirm once your payment is verified.</p>
    </div>
  `;
}

function statusClass(status) {
  return status.toLowerCase().includes("pending") ? "placed" : "confirmed";
}

function render() {
  const orders = getOrders();

  if (orders.length === 0) {
    ordersList.innerHTML = `
      <div class="empty-state">
        <div class="emoji">📦</div>
        <p>You have no orders yet.</p>
        <a class="shop-btn" href="products.html">Start Shopping</a>
      </div>
    `;
    return;
  }

  ordersList.innerHTML = orders
    .map((order) => {
      const date = new Date(order.date).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric"
      });
      return `
      <div class="order-card">
        <div class="order-head">
          <span>${order.orderId} · ${date}</span>
          <span class="order-status ${statusClass(order.status)}">${order.status}</span>
        </div>
        ${order.items
          .map(
            (item) => `
          <div class="order-item-row">
            <img src="${item.image}" alt="${item.name}" />
            <div class="row-info">
              <div class="row-name">${item.name}</div>
              <div class="row-price">${formatINR(item.price)} × ${item.qty}</div>
            </div>
          </div>
        `
          )
          .join("")}
        <div class="order-foot">
          <span>Paid via ${order.paymentMethod}</span>
          <span>${formatINR(order.total)}</span>
        </div>
      </div>
    `;
    })
    .join("");
}

render();
