import { getProductById, discountPercent } from "./data.js";
import { renderHeader } from "./ui.js";
import { formatINR, showToast, updateBadges } from "./ui.js";
import { addToCart, isInCart, toggleWishlist, isInWishlist } from "./storage.js";

const params = new URLSearchParams(window.location.search);
const id = Number(params.get("id"));
const product = getProductById(id);

const pdRoot = document.getElementById("pd-root");
const stickyRoot = document.getElementById("pd-sticky-root");

if (!product) {
  renderHeader(null, { simple: true, title: "Product Not Found", backHref: "products.html" });
  pdRoot.innerHTML = `
    <div class="empty-state">
      <div class="emoji">😕</div>
      <p>This product could not be found.</p>
      <a class="shop-btn" href="products.html">Browse Products</a>
    </div>
  `;
} else {
  renderHeader(null, { simple: true, title: "Product Details", backHref: "products.html" });
  renderProduct();
}

function renderProduct() {
  const discount = discountPercent(product);
  const wished = isInWishlist(product.id);
  const inCart = isInCart(product.id);

  pdRoot.innerHTML = `
    <div class="pd-gallery">
      <img src="${product.image}" alt="${product.name}" />
    </div>
    <div class="pd-body">
      <div class="pd-brand">${product.brand} · ${product.category}</div>
      <h1 class="pd-name">${product.name}</h1>
      <span class="pd-rating">${product.rating} ★</span>
      <span class="pd-reviews">${product.reviews.toLocaleString("en-IN")} Ratings</span>

      <div class="pd-price-row">
        <span class="pd-price">${formatINR(product.price)}</span>
        <span class="pd-mrp">${formatINR(product.mrp)}</span>
        <span class="pd-discount">${discount}% off</span>
      </div>

      <div class="pd-offer-box">
        🏷️ Special Price Deal applied on this product. Final price shown above already includes the discount.
      </div>

      <button id="wish-toggle" class="add-btn ${wished ? "in-cart" : ""}" style="margin-top:14px;width:100%;">
        ${wished ? "♥ Remove from Wishlist" : "♡ Add to Wishlist"}
      </button>
    </div>

    <div class="pd-section">
      <h3>Product Description</h3>
      <p class="pd-desc">${product.description}</p>
    </div>

    <div class="pd-section">
      <h3>Specifications</h3>
      <table class="spec-table">
        ${product.specs.map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join("")}
      </table>
    </div>

    <div class="pd-section">
      <h3>Delivery &amp; Payment</h3>
      <p class="pd-desc">Pay via UPI (PhonePe / Paytm) or Scan &amp; Pay QR at checkout. Standard delivery in 5-7 business days.</p>
    </div>

    <div style="height:90px;"></div>
  `;

  stickyRoot.innerHTML = `
    <div class="pd-sticky-bar">
      <button class="btn-add-cart" id="add-cart-btn">${inCart ? "Go to Cart" : "Add to Cart"}</button>
      <button class="btn-buy-now" id="buy-now-btn">Buy Now</button>
    </div>
  `;

  document.getElementById("wish-toggle").addEventListener("click", () => {
    toggleWishlist(product.id);
    const nowWished = isInWishlist(product.id);
    const btn = document.getElementById("wish-toggle");
    btn.textContent = nowWished ? "♥ Remove from Wishlist" : "♡ Add to Wishlist";
    btn.classList.toggle("in-cart", nowWished);
    showToast(nowWished ? "Added to Wishlist" : "Removed from Wishlist");
    updateBadges();
  });

  document.getElementById("add-cart-btn").addEventListener("click", () => {
    if (isInCart(product.id)) {
      window.location.href = "cart.html";
      return;
    }
    addToCart(product.id, 1);
    showToast("Added to Cart");
    updateBadges();
    document.getElementById("add-cart-btn").textContent = "Go to Cart";
  });

  document.getElementById("buy-now-btn").addEventListener("click", () => {
    if (!isInCart(product.id)) {
      addToCart(product.id, 1);
    }
    window.location.href = `checkout.html?buyNow=${product.id}`;
  });
}
