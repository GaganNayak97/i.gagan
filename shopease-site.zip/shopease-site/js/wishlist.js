import { getProductById } from "./data.js";
import { renderHeader, renderBottomNav, formatINR, showToast, updateBadges } from "./ui.js";
import { getWishlist, removeFromWishlist, addToCart, isInCart } from "./storage.js";

renderHeader("wishlist");
renderBottomNav("wishlist");

const listRoot = document.getElementById("wishlist-list");

function render() {
  const ids = getWishlist();
  const items = ids.map(getProductById).filter(Boolean);

  if (items.length === 0) {
    listRoot.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🤍</div>
        <p>Your wishlist is empty.</p>
        <a class="shop-btn" href="products.html">Explore Products</a>
      </div>
    `;
    return;
  }

  listRoot.innerHTML = items
    .map(
      (item) => `
    <div class="row-card" data-id="${item.id}">
      <a href="product-details.html?id=${item.id}"><img src="${item.image}" alt="${item.name}" /></a>
      <div class="row-info">
        <a href="product-details.html?id=${item.id}"><div class="row-name">${item.name}</div></a>
        <div class="row-price">${formatINR(item.price)} <span style="color:var(--muted);text-decoration:line-through;font-weight:400;font-size:12px;">${formatINR(item.mrp)}</span></div>
        <div class="row-actions">
          <button class="link-btn move" data-add="${item.id}">${isInCart(item.id) ? "In Cart ✓" : "Add to Cart"}</button>
          <button class="link-btn" data-remove="${item.id}">Remove</button>
        </div>
      </div>
    </div>
  `
    )
    .join("");

  listRoot.querySelectorAll("[data-add]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.add);
      if (!isInCart(id)) {
        addToCart(id, 1);
        showToast("Added to Cart");
        updateBadges();
        render();
      }
    });
  });
  listRoot.querySelectorAll("[data-remove]").forEach((btn) => {
    btn.addEventListener("click", () => {
      removeFromWishlist(Number(btn.dataset.remove));
      showToast("Removed from Wishlist");
      updateBadges();
      render();
    });
  });
}

render();
