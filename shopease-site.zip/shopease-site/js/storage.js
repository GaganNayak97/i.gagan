const CART_KEY = "se_cart";
const WISHLIST_KEY = "se_wishlist";
const ORDERS_KEY = "se_orders";

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ---------------- CART ---------------- */
// cart = [{ id, qty }]
export function getCart() {
  return read(CART_KEY, []);
}
export function setCart(cart) {
  write(CART_KEY, cart);
}
export function addToCart(id, qty = 1) {
  const cart = getCart();
  const existing = cart.find((c) => c.id === id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id, qty });
  }
  setCart(cart);
  return cart;
}
export function updateCartQty(id, qty) {
  let cart = getCart();
  if (qty <= 0) {
    cart = cart.filter((c) => c.id !== id);
  } else {
    const item = cart.find((c) => c.id === id);
    if (item) item.qty = qty;
  }
  setCart(cart);
  return cart;
}
export function removeFromCart(id) {
  const cart = getCart().filter((c) => c.id !== id);
  setCart(cart);
  return cart;
}
export function clearCart() {
  setCart([]);
}
export function isInCart(id) {
  return getCart().some((c) => c.id === id);
}
export function cartCount() {
  return getCart().reduce((sum, c) => sum + c.qty, 0);
}

/* ---------------- WISHLIST ---------------- */
// wishlist = [id, id, ...]
export function getWishlist() {
  return read(WISHLIST_KEY, []);
}
export function toggleWishlist(id) {
  let list = getWishlist();
  if (list.includes(id)) {
    list = list.filter((x) => x !== id);
  } else {
    list.push(id);
  }
  write(WISHLIST_KEY, list);
  return list;
}
export function isInWishlist(id) {
  return getWishlist().includes(id);
}
export function removeFromWishlist(id) {
  const list = getWishlist().filter((x) => x !== id);
  write(WISHLIST_KEY, list);
  return list;
}
export function wishlistCount() {
  return getWishlist().length;
}

/* ---------------- ORDERS ---------------- */
// orders = [{ orderId, items:[{id,qty,price,name,image}], address, paymentMethod, utr, total, date, status }]
export function getOrders() {
  return read(ORDERS_KEY, []);
}
export function addOrder(order) {
  const orders = getOrders();
  orders.unshift(order);
  write(ORDERS_KEY, orders);
  return orders;
}

/* ---------------- CHECKOUT DRAFT (address chosen before payment) ---------------- */
export function saveCheckoutDraft(draft) {
  sessionStorage.setItem("se_checkout_draft", JSON.stringify(draft));
}
export function getCheckoutDraft() {
  const raw = sessionStorage.getItem("se_checkout_draft");
  return raw ? JSON.parse(raw) : null;
}
export function clearCheckoutDraft() {
  sessionStorage.removeItem("se_checkout_draft");
}
