# ShopEase — Static E-commerce Site

Plain HTML + CSS + JS. No build step, no npm, no server required to test — just open `index.html` in a browser (or upload the whole folder to any static host).

## Folder structure

```
shopease-site/
├── index.html              ← Home page (open this to start)
├── products.html
├── product-details.html
├── cart.html
├── wishlist.html
├── checkout.html
├── payment.html
├── orders.html
├── css/
│   └── style.css
├── js/
│   ├── data.js              ← Product data (edit here to change products/prices)
│   ├── storage.js           ← Cart/Wishlist/Orders (localStorage)
│   ├── ui.js                ← Shared header + bottom nav
│   ├── product-card.js
│   ├── home.js
│   ├── products.js
│   ├── product-details.js
│   ├── cart.js
│   ├── wishlist.js
│   ├── checkout.js
│   ├── payment.js
│   └── orders.js
└── images/
    └── (put your payment-qr.png here)
```

## How to run

- **Easiest:** double-click `index.html` — it opens directly in your browser and every page/link works, since all paths are relative.
- **Or serve it** (optional, only needed if you want to test like a real deployed site):
  ```bash
  npx serve .
  ```
  or
  ```bash
  python3 -m http.server 8080
  ```

## Before going live

1. **Add your real QR code** at `images/payment-qr.png`.
2. **Set your real UPI ID** — edit the `UPI_ID` constant near the top of `js/payment.js`.
3. **Payment verification is manual.** This is a static site with no backend/payment gateway. After a customer enters their UTR/reference number, the order is saved (in the browser's `localStorage`) with status "Payment Verification Pending" — you check your bank/UPI app yourself before fulfilling the order.
4. Cart / Wishlist / Orders are stored per-browser (`localStorage`), not on any server.

## Notes

- Only the 3 products you provided are in the site (`js/data.js`) — nothing extra added.
- No login / signup / profile, as requested.
- Prices show real MRP vs. genuine discounted price (not inflated fake percentages).
- Product photos are generic stock images, not the original Flipkart listing photos.
